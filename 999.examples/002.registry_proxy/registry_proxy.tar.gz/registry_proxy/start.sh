#!/bin/bash 

source ~/.bashrc

cd $(dirname $0)

docker-compose -f docker-compose-registry-proxy.yml  up -d 
